/*
 *  main.m
 *  ObjCOSC
 *
 *  Created by C. Ramakrishnan on Tue Oct 01 2002.
 *  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
 *
 */

#import <ObjCOSC/OSCPort.h>
 
#define portno 57123

// run dumpOSC and connect it to the portno
int main (int argc, char** argv)
{
    NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
    
    char	address[9] = "127.0.0.1";	// loopback address
    short	portNumber = portno;
    
    OSCPort* 	port = [OSCPort oscPortToAddress: address portNumber: portNumber];
    
    [port sendTo:"/foo/bar" types:"f", 128.4920];
    [port sendTo:"/baz" types:"s", "a string"];
    [port sendTo:"/foo/bar*" types:"sif", "a string", 20, 9483.0249];
    
 
    [port loadSynthDef:"synthdefs/foo.scsyndef"];
    [port newSynthFromDef:"foo" synthID:1 parentGroup:0];
    [port freeSynth:1];
    
    [pool release];

    return 0;
}

