//
//  SimpleSCExampleController.h
//  SimpleSCExample
//
//  Created by C. Ramakrishnan on Tue Oct 01 2002.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//

#import <AppKit/AppKit.h>
#import <ObjCOSC/OSCPort.h>


@interface SimpleSCExampleController : NSWindowController {
    OSCPort* port;
    
    IBOutlet id slider;
}

- (IBAction)start:(id)sender;
- (IBAction)stop:(id)sender;
- (IBAction)setFrequency:(id)sender;

@end
