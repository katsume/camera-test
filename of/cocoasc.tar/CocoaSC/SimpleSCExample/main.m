//
//  main.m
//  SimpleSCExample
//
//  Created by C. Ramakrishnan on Tue Oct 01 2002.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
