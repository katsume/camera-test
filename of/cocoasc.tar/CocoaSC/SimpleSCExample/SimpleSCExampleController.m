//
//  SimpleSCExampleController.m
//  SimpleSCExample
//
//  Created by C. Ramakrishnan on Tue Oct 01 2002.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//

#import "SimpleSCExampleController.h"
#define SC_DEFAULT_OSC_PORT 57110

@implementation SimpleSCExampleController

- (void)awakeFromNib
{
    port = [OSCPort oscPortToAddress:"127.0.0.1" portNumber:SC_DEFAULT_OSC_PORT];
    [port retain];
}

- (IBAction)start:(id)sender
{
    [port loadSynthDef:"synthdefs/sine.scsyndef"];
    [port newSynthFromDef:"sine" synthID:1 parentGroup:0];
    [self setFrequency:slider];
}

- (IBAction)stop:(id)sender
{
    [port freeSynth:1];
}

- (IBAction)setFrequency:(id)sender
{
    [port sendTo:"/n_set" types:"isf", 1, "freq", [sender floatValue]];
}

@end
